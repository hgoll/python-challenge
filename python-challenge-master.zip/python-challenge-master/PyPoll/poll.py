import os
import csv

csvpath = os.path.join('pypoll.csv')

voter = []
county = []
candidate = []
    
    ## print(row)



with open(csvpath, newline='') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=',')
    csv_header = next(csvreader)

    count = 0
    total_amount = 0

    for row in csvreader:
        #voter.append(row[0])
        #county.append(row[1])
        #candidate.append(row[2])
        count = count +1 
        total_amount = (total_amount + int(row[2]))

    #print(voter)
    #print(county)
    #print(candidate)

    print(count)
    print(total_amount)
    

num_rows = -1

for row in open("pypoll.csv"):
    num_rows += 1

print(num_rows)