import os
import csv

csvpath = os.path.join('PyBank1.csv')


with open(csvpath, newline='') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=',')
    csv_header = next(csvreader)
    
    count = 0
    total_amount = 0
    average_change = 0
    for row in csvreader:
        count = count +1 
        total_amount = (total_amount + int(row[1]))
        average_change = total_amount/count
        #greatest_increase =
        #greatest_decrease =
    print (count)
    print (total_amount)
    print (average_change)


#type(row)





   
    

#Initialize array     
    #arr = [[1,2]];     
    #sum = 0;    
     
#Loop through the array to calculate sum of elements  
#for i in range(2, len(arr)):    
   #sum = sum + arr[i];    
     
#print("Total: " + str(sum));
    
    
    #for row in csvreader:
     #   profits.append(row[1])
      #  dates.append(row[0])
    
   # print(profits)
    #print(dates)

