import os
import csv

csvpath = os.path.join('pybankWrite.csv')
#csv_write = os.path.join('pybankwrite.csv')
indexes = [1, 2, 3, 4, 5]
titles = ["Total Months", "Total", "Average Change", 
"Greatest Increase in Profits", "Greatest Decrease in Profits"]
values = ["86", "$38382578", "$-2315.12", "Feb-2012 ($1926159)", 
"Sep-2013 ($-2196167)"]

roster = zip(indexes, titles, values)

for row in roster:
    print(row)

output_file = os.path.join('pybankWrite.csv')

with open(output_file, "w") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["Index", "Title", "Value"])
    writer.writerows(roster)

with open(csvpath, newline='') as csvfile:
    
    csvreader = csv.reader(csvfile, delimiter=',')
    
    for row in csvreader:
        print(row)


num_rows = -1

for row in open("pybankWrite.csv"):
    num_rows += 1

print(num_rows)


#with open(csvpath, newline='') as csvfile:
    #csvreader =csv.reader(csvfile, delimiter=',')
    #for row in csvreader:
        #print (sum)
    